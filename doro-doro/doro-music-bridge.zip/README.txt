ドロドロ Music Bridge

Extract this folder, open chrome://extensions (or your Chromium browser’s Extensions page), enable Developer mode, and Load unpacked. Reload your timer and music tabs. Start music on the music site first.

Only Spotify Web, YouTube, YouTube Music, and https://valorance.net/doro-doro/ are supported. No backend, tokens, tracking, storage, or external requests. Metadata and control messages stay inside the browser. Uninstall to disconnect. Service interface changes or browser playback policies may limit controls. Not a Chrome Web Store extension.
