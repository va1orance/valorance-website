(() => {
 const host=location.hostname;
 if(!['open.spotify.com','www.youtube.com','music.youtube.com'].includes(host))return;
 const text=s=>document.querySelector(s)?.textContent?.trim()||'';
 const media=()=>[...document.querySelectorAll('video,audio')].find(m=>!m.paused)||document.querySelector('video,audio');
 const spotify=host==='open.spotify.com',ytm=host==='music.youtube.com';
 function snapshot(){
  const m=media();let title='',artist='',paused=true;
  if(spotify){title=text('[data-testid="context-item-info-title"]')||text('[data-testid="now-playing-widget"] [data-testid="context-item-link"]');artist=text('[data-testid="context-item-info-subtitles"]');const play=document.querySelector('[data-testid="control-button-playpause"]');paused=play?!/pause/i.test(play.getAttribute('aria-label')||''):m?.paused??true;}
  else if(ytm){title=text('ytmusic-player-bar .title');artist=text('ytmusic-player-bar .byline');paused=m?.paused??true;}
  else{title=text('ytd-watch-metadata h1')||text('#title h1');artist=text('ytd-video-owner-renderer #channel-name');paused=m?.paused??true;}
  return title?{title:title.slice(0,300),artist:artist.slice(0,200),paused,source:spotify?'Spotify':ytm?'YouTube Music':'YouTube'}:null;
 }
 chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(sender.id!==chrome.runtime.id||message?.type!=='doro-player'||!['state','toggle','next','previous'].includes(message.command))return;
  (async()=>{
   if(message.command!=='state'){
    const selectors=spotify?{toggle:'[data-testid="control-button-playpause"]',next:'[data-testid="control-button-skip-forward"]',previous:'[data-testid="control-button-skip-back"]'}:ytm?{toggle:'#play-pause-button',next:'.next-button',previous:'.previous-button'}:{toggle:'.ytp-play-button',next:'.ytp-next-button',previous:'.ytp-prev-button'};
    const button=document.querySelector(selectors[message.command]);
    if(button&&!button.disabled&&button.getAttribute('aria-disabled')!=='true')button.click();
    else if(message.command==='toggle'&&media()){const m=media();if(m.paused)await m.play();else m.pause();}
    else {reply({state:snapshot(),error:'This control is unavailable on the music tab.'});return}
    await new Promise(r=>setTimeout(r,180));
   }
   reply({state:snapshot()});
  })().catch(()=>reply({state:snapshot(),error:'Start playback on the music tab first.'}));
  return true;
 });
})();
