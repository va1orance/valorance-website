const musicURLs=['https://open.spotify.com/*','https://www.youtube.com/*','https://music.youtube.com/*'];
let selected=null;
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 let url;try{url=new URL(sender.url)}catch{return}
 if(url.origin!=='https://valorance.net'||!url.pathname.startsWith('/doro-doro/')||message?.type!=='doro-request'||!['state','toggle','next','previous'].includes(message.command))return;
 (async()=>{
  const tabs=await chrome.tabs.query({url:musicURLs});
  const tracks=(await Promise.all(tabs.map(async tab=>{try{return {id:tab.id,audible:tab.audible,...await chrome.tabs.sendMessage(tab.id,{type:'doro-player',command:'state'})}}catch{return null}}))).filter(t=>t?.state?.title);
  const target=message.command==='state'?(tracks.find(t=>!t.state.paused&&t.audible)||tracks.find(t=>!t.state.paused)||tracks.find(t=>t.id===selected)||tracks[0]):tracks.find(t=>t.id===selected);
  if(!target){reply({state:null});return}
  selected=target.id;
  if(message.command==='state'){reply({state:target.state});return}
  reply(await chrome.tabs.sendMessage(target.id,{type:'doro-player',command:message.command}));
 })().catch(()=>reply({state:null,error:'Music tab unavailable. Reload the music tab and try again.'}));
 return true;
});
