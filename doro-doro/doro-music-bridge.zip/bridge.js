(() => {
 if(location.origin!=='https://valorance.net'||!location.pathname.startsWith('/doro-doro/'))return;
 let pending=false;
 window.addEventListener('message',async e=>{
  if(e.source!==window||e.origin!==location.origin||e.data?.channel!=='doro-music-page'||!['state','toggle','next','previous'].includes(e.data.command))return;
  if(pending&&e.data.command==='state')return;
  pending=true;
  try{const result=await chrome.runtime.sendMessage({type:'doro-request',command:e.data.command});window.postMessage({channel:'doro-music-extension',...result},location.origin)}catch{}finally{pending=false}
 });
})();
